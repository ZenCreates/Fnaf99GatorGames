namespace SDK.Addresses
{
    public static class Hardcoded
    {
        public static string Payload = "oc4ZXvZ/AADiyqNd9n8AAGhxpF32fwAAXiykXfZ/AADg1Dde9n8AACAAAAAQAAAAGAAAAEAAAABQAAAASAAAACgAAAAAAAAACAAAACAAAAAoAAAATAAAAHgAAABCAAAAsAAAAEAAAABIAAAA";
    }
}

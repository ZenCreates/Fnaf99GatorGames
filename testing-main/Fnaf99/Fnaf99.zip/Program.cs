﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Numerics;
using UnrealSharp;
using SDK.Script.EngineSDK;
using Console = System.Console;
using System.IO;
using Newtonsoft.Json;
using System.Reflection;
using SDK.Script.CoreUObjectSDK;

namespace Fnaf99
{
    public class UEObjectInfo
    {
        public string path;
        public string type;
        public List<UEObjectInfo> children = new List<UEObjectInfo>();
        public Vector3 position;
        public Vector3 rotation;
        public Vector3 scale;
    }
    public class Settings
    {
        public string AESKey;
        public string gameName;
        public string pakFolder;
    }
    
    internal class Program
    {
        public static List<UEObjectInfo> objects = new List<UEObjectInfo>();
        static String staticGameName = "freddys-Win64-Shipping";



        static Process process;
        static List<UEObject> Players = new List<UEObject>();


        //public UEObject GetLevelManager()
        //{
        //    var World = new UEObject(UnrealEngine.Memory.ReadProcessMemory<UInt64>(UnrealEngine.GWorldPtr)).As<SDK.Script.EngineSDK.World>(); if (World == null || !World.IsA("Class /Script/Engine.World")) return null;
        //    var PersistentLevel = World["PersistentLevel"];
        //    var Levels = World["Levels"];
        //    var OwningGameInstance = World["OwningGameInstance"]; if (OwningGameInstance == null || !OwningGameInstance.IsA("Class /Script/Engine.GameInstance")) return null;
        //    var LocalPlayers = OwningGameInstance["LocalPlayers"]; if (LocalPlayers == null) return null;
        //    var PlayerController = LocalPlayers[0]["PlayerController"].As<SDK.Script.EngineSDK.PlayerController>();
        //    for (var levelIndex = 0u; levelIndex < Levels.Num; levelIndex++)
        //    {
        //        var Level = Levels[levelIndex];
        //        var Actors = new UEObject(Level.Address + 0xA8); // todo fix hardcoded 0xA8 offset...
        //        var y = 0;
        //        for (var i = 0u; i < Actors.Num; i++)
        //        {
        //            if (Actors[i].ClassName.Contains("FNAFLevelManager"))
        //            {
        //                Players.Add(Actors[i]);
        //            }
        //        }
        //    }
        //}
        static List<string> alreadyDumped = new List<string>();
        public static void UpdateAllGregorys()
        {
            
            try
            {
                Directory.CreateDirectory("Dump");
                var World = new UEObject(UnrealEngine.Memory.ReadProcessMemory<UInt64>(UnrealEngine.GWorldPtr)); if (World == null || !World.IsA("Class /Script/Engine.World")) return;
                var PersistentLevel = World["PersistentLevel"];
                var worldObj = World.As<SDK.Script.EngineSDK.World>().Levels;
                for (uint i = 0; i < worldObj.Num; i++)
                {
                    var level = worldObj[i];
                    Console.WriteLine(level.ClassName);
                    //if(level.ClassName.Contains("With_Showtime"))
                    {
                        Console.WriteLine("FOUND LEVEL: "+ level.Address.ToString("X2"));
                        var Actors = new UEObject(level.Address + 0x98); // todo fix hardcoded 0xA8 offset...
                        for (var a = 0u; a < Actors.Num; a++)
                        {
                            var Actor = Actors[a];
                            if (Actor.Address == 0) continue;
                            if (Actor.IsA("Class /Script/Engine.Actor"))
                            {
                                if (Actor.IsA<StaticMeshActor>())
                                {
                                    var staticMeshActor = Actor.As<StaticMeshActor>();
                                    var pos = staticMeshActor.K2_GetActorLocation();
                                    var rot = staticMeshActor.K2_GetActorRotation();
                                    var scl = staticMeshActor.GetActorScale3D();
                                    var newObject = new UEObjectInfo();
                                    var namme = staticMeshActor.StaticMeshComponent.StaticMesh.GetFullPath().Split(' ');
                                    
                                    newObject.path =namme[1];
                                    newObject.type = "mesh";
                                    newObject.position = pos;
                                    newObject.rotation = rot;
                                    newObject.scale = scl;
                                    objects.Add(newObject);
                                    if (alreadyDumped.Contains(namme[1])) continue;

                                    var args = "";
                                    args += $"\"{settings.pakFolder}\"";
                                    args += " ";
                                    args += $"-aes={settings.AESKey}";
                                    args += " ";
                                    args += "-game=ue4.25";
                                    args += " ";
                                    args += $"-pkg={namme[1].Split('.')[0]}";
                                    args += " ";
                                    try
                                    {
                                        args += $"-export {namme[1].Split('.')[1]}";
                                    }
                                    catch { }

                                    Console.WriteLine("Processing "+namme[1]+" "+ a);

                                    Process p = new Process();
                                    p.StartInfo = new ProcessStartInfo($"{Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName)}\\umodel\\umodel.exe");
                                    p.StartInfo.Arguments = args;
                                    p.StartInfo.WorkingDirectory = Directory.GetCurrentDirectory()+"\\Dump";
                                    p.StartInfo.CreateNoWindow = true;
                                    p.StartInfo.UseShellExecute = false;
                                    p.Start();
                                    alreadyDumped.Add(namme[1]);

                                }
                                else
                                {
                                    var realActor = Actor.As<Actor>();
                                   
                                    var root = realActor["RootComponent"];
                                    Console.WriteLine($"Doing recursive dumping for object {realActor.GetShortName()} {a}");
                                    //Console.WriteLine($"SKIPPING {realActor.GetShortName()}. Root component - {root.GetShortName()}");
                                    if (root.IsA(out SceneComponent sceneComponent))
                                    {
                                        var newObject = new UEObjectInfo();
                                        newObject.type = "dummy";
                                        newObject.position = realActor.K2_GetActorLocation();
                                        objects.Add(newObject);
                                        DumpComponentsRecursively(ref objects,sceneComponent.AttachChildren,sceneComponent,newObject);
                                    }
                                    else if(root.IsA(out StaticMeshComponent sm))
                                    {
                                        var newObject = new UEObjectInfo();
                                        var namme = sm.StaticMesh.GetFullPath().Split(' ');
                                        newObject.path = namme[1];
                                        newObject.type = "mesh";
                                        var pos = realActor.K2_GetActorLocation();
                                        var rot = realActor.K2_GetActorRotation();
                                        var scl = realActor.GetActorScale3D();
                                        newObject.position = pos;
                                        newObject.rotation = rot;
                                        newObject.scale = scl;


                                        if (alreadyDumped.Contains(namme[1])) continue;

                                        var args = "";
                                        args += $"\"{settings.pakFolder}\"";
                                        args += " ";
                                        args += $"-aes={settings.AESKey}";
                                        args += " ";
                                        args += "-game=ue4.25";
                                        args += " ";
                                        args += $"-pkg={namme[1].Split('.')[0]}";
                                        args += " ";

                                        try
                                        {
                                            args += $"-export {namme[1].Split('.')[1]}";
                                        }
                                        catch
                                        {
                                        }

                                        Process p = new Process();
                                        p.StartInfo = new ProcessStartInfo($"{Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName)}\\umodel\\umodel.exe");
                                        p.StartInfo.Arguments = args;
                                        p.StartInfo.WorkingDirectory = Directory.GetCurrentDirectory() + "\\Dump";
                                        p.StartInfo.CreateNoWindow = true;
                                        p.StartInfo.UseShellExecute = false;
                                        p.Start();
                                    }
                                    
                                    //Console.ReadKey();
                                }
                            }
                        }
                        
                    }
                    
                }
                var stringLevel = JsonConvert.SerializeObject(objects);
                File.WriteAllText("Dump\\dump.json", stringLevel);
                Console.WriteLine("Done");
                while (true) { }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.ReadKey();
            }
        }
        public static void DumpComponentsRecursively(ref List<UEObjectInfo> objs, Array<SceneComponent> children,SceneComponent parent,UEObjectInfo parentObject)
        {
            var count = children.Num;
            
            for (uint i = 0; i < children.Num; i++)
            {
                if(children[i].IsA(out StaticMeshComponent sm))
                {
                    var newObject = new UEObjectInfo();
                    var namme = sm.StaticMesh.GetFullPath().Split(' ');
                    newObject.path = namme[1];
                    newObject.type = "mesh";

                    newObject.position = parentObject.position;
                    newObject.rotation = parentObject.rotation;
                    newObject.scale = parentObject.scale;
                    newObject.position.X += sm.RelativeLocation.X;
                    newObject.position.Y += sm.RelativeLocation.Y;
                    newObject.position.Z += sm.RelativeLocation.Z;
                    newObject.rotation.X += sm.RelativeRotation.Pitch;
                    newObject.rotation.Y += sm.RelativeRotation.Yaw;
                    newObject.rotation.Z += sm.RelativeRotation.Roll;
                    newObject.scale.X += sm.RelativeScale3D.X;
                    newObject.scale.Y += sm.RelativeScale3D.Y;
                    newObject.scale.Z += sm.RelativeScale3D.Z;
                    parentObject.children.Add(newObject);
                    
                    if (alreadyDumped.Contains(namme[1])) continue;
                    var args = "";
                    args += $"\"{settings.pakFolder}\"";
                    args += " ";
                    args += $"-aes={settings.AESKey}";
                    args += " ";
                    args += "-game=ue4.25";
                    args += " ";
                    args += $"-pkg={namme[1].Split('.')[0]}";
                    args += " ";
                    
                    try
                    {
                        args += $"-export {namme[1].Split('.')[1]}";
                    }
                    catch { 
                    }
                    Process p = new Process();
                    p.StartInfo = new ProcessStartInfo($"{Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName)}\\umodel\\umodel.exe");
                    p.StartInfo.Arguments = args;
                    p.StartInfo.WorkingDirectory = Directory.GetCurrentDirectory() + "\\Dump";
                    p.StartInfo.CreateNoWindow = true;
                    p.StartInfo.UseShellExecute = false;
                    p.Start();

                    DumpComponentsRecursively(ref objs, sm.AttachChildren, sm, newObject);  
                }
                else if(children[i].IsA(out SceneComponent sc))
                {
                    var newObject = new UEObjectInfo();
                    newObject.type = "dummy";

                    newObject.position = parentObject.position;
                    newObject.rotation = parentObject.rotation;
                    newObject.scale = parentObject.scale;
                    newObject.position.X += sc.RelativeLocation.X;
                    newObject.position.Y += sc.RelativeLocation.Y;
                    newObject.position.Z += sc.RelativeLocation.Z;
                    newObject.rotation.X += sc.RelativeRotation.Pitch;
                    newObject.rotation.Y += sc.RelativeRotation.Yaw;
                    newObject.rotation.Z += sc.RelativeRotation.Roll;
                    newObject.scale.X += sc.RelativeScale3D.X;
                    newObject.scale.Y += sc.RelativeScale3D.Y;
                    newObject.scale.Z += sc.RelativeScale3D.Z;

                    parentObject.children.Add(newObject);
                    DumpComponentsRecursively(ref objs, sc.AttachChildren, sc, newObject);
                }

            }

        }
        



       static void GetProcess()
        {
            while (true)
            {
                if (staticGameName != "autogenerate") process = Process.GetProcesses().FirstOrDefault(p => p.ProcessName.Contains(staticGameName) && p.MainWindowHandle != IntPtr.Zero);
                if (process != null) break;
                Thread.Sleep(500);
            }
        }

        Object sync = new Object();
        public static void Initlize()
        {
            if (process == null)
            {
                try
                {
                    GetProcess();
                    new UnrealEngine(new Memory(process)).UpdateAddresses();
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                }
                
            }

        }
        public static Settings settings;

        static void Main(string[] args)
        {

            Console.Title = "Made by kostya#3333 and ItzNotSpookyy#5139";
            settings = JsonConvert.DeserializeObject<Settings>(File.ReadAllText("settings.json"));
            staticGameName = settings.gameName;

            Initlize();
            UpdateAllGregorys();

        }
    }
}
